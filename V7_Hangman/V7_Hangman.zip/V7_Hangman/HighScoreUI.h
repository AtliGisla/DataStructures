#ifndef HIGHSCOREUI_H
#define HIGHSCOREUI_H

#include <fstream>
#include <iostream>

#include "GameData.h"

using namespace std;

class HighScoreUI{
    public:
        void main();
};

#endif

using namespace std;

#include "MainUI.h"

int main()
{
    MainUI mainui;
    mainui.main();
    return 0;
}

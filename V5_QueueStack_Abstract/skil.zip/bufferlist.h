#ifndef BUFFERLIST_H
#define BUFFERLIST_H

#include <iostream>

#include "queue.h"
#include "stack.h"

///You MUST use this value of initial capacity when you return you final version
///but feel free to change it while testing (to first test regular functionality)
#define INITIAL_CAPACITY 4

template <class T>
class BufferList : public Stack<T>, public Queue<T>
{
    public:
        BufferList() {

            ///TODO: Initialize buffer (dynamic array) of size INITIAL_CAPACITY (this is important!!)
            capacity = INITIAL_CAPACITY;
            arr = new T[capacity];
            size = 0;
        }

        virtual ~BufferList() {
            delete[] arr;
        }

        ///TODO: Override functions from Stack ADT
        
        void push(T data) {
            if(size + 1 > capacity){
                resize();
            }
            arr[size] = data;
            size++;
        }

        T pop() {
            if(size == 0){
                throw EmptyException();
            }
            T output = arr[size - 1];
            size--;
            return output;
        }

        ///TODO: Override functions from Queue ADT
    
        void add(T data) {
            if(size + 1 > capacity){
                resize();
            }
            arr[size] = data;
            size++;
        }

        T remove() {
            if(size == 0){
                throw EmptyException();
            }
            T output = arr[0];
            for(int i = 0; i < size - 2; i++){
                arr[i] = arr[i + 1];
            }
            return output;
        }

        ///print override:
        void print(ostream &outs) const {
        
        for(int i = 0; i < size; i++){
            outs << arr[i] << " ";
        }
        ///TODO: Implement print for your own testing
            ///This is not tested on Mooshak, so it doesn't
            ///matter exactly how you print the list
        }

        friend ostream& operator <<(ostream& outs, const BufferList<T> &lis) {
            lis.print(outs);
            return outs;
        }

    private:
        ///TODO: Set up class variables and private helper functions, as needed
        T* arr;
        int size;
        int capacity;

        void resize() {
            capacity *= 2;
            T* newArr = new T[capacity];
            for(int i = 0; i < size; i++){
                newArr[i] = arr[i];
            }
            delete[] arr;
            arr = newArr;
        };
};

#endif // BUFFERLIST_H


#include "library.h"

//Constructors
Library::Library(){

    this->books = NULL;
    this->storageSpace = 0;
    this->bookCount = 0;
}

Library::Library(int storageSpace){

    this->books = new Book[storageSpace];
    this->storageSpace = storageSpace;
    this->bookCount = 0;
}

Library::~Library(){

    delete[] books;
}

void Library::addBook(Book book) {

    if(false) {  ///If the library is full (change conditions)
        throw LibraryFullException();
    }
    if(false) {  ///If book is already in the library (change conditions)
        throw AlreadyInLibraryException();
    }

    ///TODO: Implement
}

void Library::checkOutBookByISBN(int ISBN){

    if(false) {  ///If book is already checked out (change conditions)
        throw BookAlreadyCheckedOutException();
    }

    ///TODO: Implement

    ///If book was not found in library
    throw BookNotFoundException();
}

void Library::checkOutBookByTitle(string title){

    if(false) {  ///If book is already checked out (change conditions)
        throw BookAlreadyCheckedOutException();
    }

    ///TODO: Implement

    ///If book was not found in library
    throw BookNotFoundException();
}

void Library::returnBookByISBN(int ISBN){

    if(false) {  ///If book is not checked out (change conditions)
        throw NotCheckedOutException();
    }

    ///TODO: Implement

    ///If book was not found in library
    throw BookNotFoundException();
}

void Library::returnBookByTitle(string title){

    if(false) {  ///If book is not checked out (change conditions)
        throw NotCheckedOutException();
    }

    ///TODO: Implement

    ///If book was not found in library
    throw BookNotFoundException();
}

ostream& operator <<(ostream& out, const Library &lib) {

    ///TODO: Implement

    return out;
}


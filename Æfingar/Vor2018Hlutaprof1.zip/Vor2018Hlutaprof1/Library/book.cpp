
#include "book.h"

//Constructors
Book::Book(){

    ///TODO_ Implement
}

Book::Book( string title, int ISBN, int pageCount, bool checked){

    ///TODO_ Implement
}

Book::~Book(){

}

//Getters
int Book::getISBN(){

    ///TODO_ Implement
}
int Book::getPageCount(){

    ///TODO_ Implement
}
string Book::getTitle(){

    ///TODO_ Implement
}
bool Book::getChecked(){

    ///TODO_ Implement
}

//Setters
void Book::setISBN(int ISBN){

    ///TODO_ Implement
}
void Book::setPageCount(int pageCount){

    ///TODO_ Implement
}
void Book::setTitle(string title){

    ///TODO_ Implement
}
void Book::setChecked(bool checked){

    ///TODO_ Implement
}

void Book::setBook(Book book){

    ///TODO_ Implement
}

//Friends
ostream& operator <<(ostream& out, const Book& book){

    out << "Title: " << book.title << endl;
    out << "ISBN: " << book.ISBN << endl;
    out << "Page count: " << book.pageCount << endl;
    if(book.checked){
        out << "Book is on loan." << endl;
    }else{
        out << "Book is available" << endl;
    }

    return out;
}

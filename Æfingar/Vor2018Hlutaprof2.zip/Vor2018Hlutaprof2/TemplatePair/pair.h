#ifndef PAIR_H
#define PAIR_H

#include <ostream>

using namespace std;

class Pair
{
    public:
        Pair() {}
        virtual ~Pair() {}

        friend ostream& operator <<(ostream& out, const Pair& p) {

            return out;
        }

    protected:

    private:
};

#endif // PAIR_H

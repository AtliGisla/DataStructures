
#ifndef Library_hpp
#define Library_hpp

#include <stdio.h>
#include "book.h"

class AlreadyInLibraryException{};
class LibraryFullException{};
class BookAlreadyCheckedOutException{};
class NotCheckedOutException{};
class BookNotFoundException{};

class Library{
public:

    //Constructors
    Library();
    Library(int bookCount);
    ~Library();

    //Functions
    void addBook(Book book);
    void checkOutBookByISBN(int ISBN);
    void checkOutBookByTitle(string title);
    void returnBookByISBN(int ISBN);
    void returnBookByTitle(string title);

    friend ostream& operator <<(ostream& out, const Library &lib);

private:
    Book& getBookByTitle(string title);
    Book& getBookByISBN(int ISBN);
    Book* books;
    int storageSpace;
    int bookCount;
};

#endif /* Library_hpp */

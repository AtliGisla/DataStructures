
#include "library.h"

//Constructors
Library::Library(){

    this->books = NULL;
    this->storageSpace = 0;
    this->bookCount = 0;
}

Library::Library(int storageSpace){

    this->books = new Book[storageSpace];
    this->storageSpace = storageSpace;
    this->bookCount = 0;
}

Library::~Library(){

    delete[] books;
}

void Library::addBook(Book book) {

    if(bookCount >= storageSpace) {
        throw LibraryFullException();
    }
    for (int i = 0; i < bookCount; i++) {
        if (books[i].getTitle() == book.getTitle()) {
            throw AlreadyInLibraryException();
        }
    }
    books[bookCount] = book;
    bookCount++;
}

void Library::checkOutBookByISBN(int ISBN){

    for (int i = 0; i < storageSpace; i++) {
        if (books[i].getISBN()== ISBN) {
            if (books[i].getChecked()) {
                throw BookAlreadyCheckedOutException();
            }else{
                books[i].setChecked(true);
            }
            return;
        }
    }
    throw BookNotFoundException();
}

void Library::checkOutBookByTitle(string title){

    for (int i = 0; i < storageSpace; i++) {
        if (books[i].getTitle()== title) {
            if (books[i].getChecked()) {
                throw BookAlreadyCheckedOutException();
            }else{
                books[i].setChecked(true);
            }
            return;
        }
    }
    throw BookNotFoundException();
}

void Library::returnBookByISBN(int ISBN){

    for (int i = 0; i < storageSpace; i++) {
        if (books[i].getISBN()== ISBN) {
            if (books[i].getChecked()) {
                books[i].setChecked(false);
            }else{
                throw NotCheckedOutException();
            }
            return;
        }
    }
    throw BookNotFoundException();
}

void Library::returnBookByTitle(string title){

    for (int i = 0; i < storageSpace; i++) {
        if (books[i].getTitle()== title) {
            if (books[i].getChecked()) {
                books[i].setChecked(false);
            }else{
                throw NotCheckedOutException();
            }
            return;
        }
    }
    throw BookNotFoundException();
}

ostream& operator <<(ostream& out, const Library &lib) {

    for (int i = 0; i < lib.bookCount; i++) {
        out << lib.books[i] << endl;
    }
    return out;
}


#ifndef LISTNODE_H
#define LISTNODE_H

#include "measurement.h"

class EmptyException{};

class ListNode
{
    public:
        ListNode(Measurement data, ListNode *next) : data(data), next(next) {};
        virtual ~ListNode(){};

        Measurement data;
        ListNode *next;
};

#endif // LISTNODE_H

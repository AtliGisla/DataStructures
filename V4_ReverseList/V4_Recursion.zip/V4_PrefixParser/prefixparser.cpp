#include <iostream>
#include "prefixparser.h"

using namespace std;

int parseExpression(istream& ins){

    return 0;

}
